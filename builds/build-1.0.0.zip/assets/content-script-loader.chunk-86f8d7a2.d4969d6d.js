(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-86f8d7a2.js")
    );
  })().catch(console.error);

})();
